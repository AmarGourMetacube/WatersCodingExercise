export class Color {
  colorBox =['#979797','#3B86FF','#8B68EE','#EE3541'];
  }
  