export class Product{
    id: number;
    title: string;
    amount: number;
    status: string;
    visible: boolean;
    description: string;
}