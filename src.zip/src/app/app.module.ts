import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OnePageComponent } from './one-page/one-page.component';
import { TwoPageComponent } from './two-page/two-page.component';
import { SubscriptionComponent } from './subscription/subscription.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from './shared/shared.module';
import { MainNavComponent } from './main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatSidenavModule } from '@angular/material/sidenav';
import { HttpClientModule } from '@angular/common/http';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { DataService } from './service/data.service';
const routes: Routes = [
  { path: 'OnePage', component: OnePageComponent },
  { path: 'TwoPage', component: TwoPageComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    OnePageComponent,
    TwoPageComponent,
    MainNavComponent,
    SubscriptionComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    SharedModule,
    RouterModule.forRoot(routes, { useHash: true }),
    LayoutModule,
    MatSidenavModule,
    HttpClientModule,
    InMemoryWebApiModule.forRoot(DataService, { delay: 0 })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
