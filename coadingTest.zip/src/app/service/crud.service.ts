import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudService {
  //API Endpoint URL
  SERVER_URL: string = "http://localhost:8080/api/";
  constructor(private httpClient: HttpClient) { }

  //
  // ─── GET ALL RECORDS API ────────────────────────────────────────────────────────
  //
  public getProducts(){
    return this.httpClient.get(this.SERVER_URL + 'products');
  }

  //
  // ─── UPDATE RECORD ──────────────────────────────────────────────────────────────
  //   
  public updateProduct(product): Observable<void>{
    console.log(product);
    return this.httpClient.put<void>(`${this.SERVER_URL + 'products'}/${product.id}`,product)
}
}
