import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { CrudService } from "../service/crud.service";
@Component({
  selector: "app-subscription",
  templateUrl: "./subscription.component.html",
  styleUrls: ["./subscription.component.scss"]
})
export class SubscriptionComponent{
  @Input() products: [];
  @Output() buyProduct = new EventEmitter<boolean>();
  constructor(private crudService: CrudService) {}

  //
  // ─── UPDATE IN API ──────────────────────────────────────────────────────────────
  //
    
  public updateProduct(product, type) {
    let productDetail = product;
    
    if (type == "buy") {
      productDetail.status = "sold";
    }
    if (type == "cancle") {
      productDetail.status = "unsold";
    }
    
    /**
    |--------------------------------------------------
    | API Calling for update result
    |--------------------------------------------------
    */
    this.crudService.updateProduct(productDetail).subscribe(
      resp => {
        this.buyProduct.emit();
      },
      err => {
        console.error(err);
      }
    );
  }
}
